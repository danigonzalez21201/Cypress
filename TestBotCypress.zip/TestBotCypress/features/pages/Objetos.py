class Objetos:
    def __init__(self):
        self.continuar = '/html/body/main/section[1]/div/div[1]/a[1]'
        self.close_window = '//*[@id="cookiescript_close"]'
        self.nombre_empresa_input = '//*[@id="user_company"]'
        self.nombre = '//*[@id="user_first_name"]'
        self.apellido = '//*[@id="user_last_name"]'
        self.correo_electronico_input = '//*[@id="user_email"]'
        self.password = '//*[@id="user_password"]'
