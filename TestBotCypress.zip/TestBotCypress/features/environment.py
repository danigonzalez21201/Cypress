import os
from datetime import datetime
from dotenv import load_dotenv

def before_all(context):
    print("🚀 Iniciando pruebas de Behave...")
    load_dotenv()

def after_scenario(context, scenario):
    """
    Toma un screenshot automáticamente después de cada escenario.
    """
    try:
        if hasattr(context, "driver"):  # Si el driver existe
            # Crear carpeta de screenshots si no existe
            if not os.path.exists("screenshots"):
                os.makedirs("screenshots")

            # Nombre del archivo con timestamp y nombre del escenario
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"screenshots/{scenario.name}_{timestamp}.png"

            # Guardar screenshot
            context.driver.save_screenshot(filename)
            print(f"📸 Screenshot guardado: {filename}")

    except Exception as e:
        print(f"⚠️ No se pudo tomar screenshot: {e}")

def after_all(context):
    print("✅ Pruebas finalizadas.")
