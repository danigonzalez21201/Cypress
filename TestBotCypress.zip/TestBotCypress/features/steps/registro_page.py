import os, time
from behave import given, when, then
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from pages.Metodos import Metodos
from pages.Objetos import Objetos

@given('que abro el navegador y navego a la página de registro')
def step_open_browser(context):
    service = Service(ChromeDriverManager().install())
    context.driver = webdriver.Chrome(service=service)
    context.driver.maximize_window()
    context.driver.get(os.getenv("URL"))
    context.metodos = Metodos(context.driver, Objetos())

@when('cierro la ventana de cookies')
def step_close_cookie(context):
    context.metodos.cerrar_ventana()

@when('lleno el formulario con datos válidos')
def step_fill_form(context):
    context.metodos.llenar_formulario(
        os.getenv("EMPRESA"),
        os.getenv("CORREO"),
        os.getenv("CLAVE"),
        os.getenv("NOMBRE"),
        os.getenv("APELLIDO"),
    )

@when('hago clic en continuar')
def step_click_continue(context):
    context.metodos.click_continuar()

@then('debería ver un mensaje de confirmación o redirección exitosa')
def step_verify(context):
    time.sleep(2)
    context.driver.save_screenshot("registro_exitosa.png")
    context.driver.quit()
